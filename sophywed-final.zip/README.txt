Upload ONLY these 3 files to GitHub (Add file > Upload files):
1. index.html
2. og-image.jpg
3. vercel.json
Make sure the names stay exactly the same. If GitHub asks to replace, say yes.
